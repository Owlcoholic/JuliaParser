function m ( )
	i = 0
	while < i 3
		i = + i 1
		for j = 0 : 4
			if == % j 2 0
				print ( j )
			else
				print ( * i 100 )
			end
		end
	end
end
